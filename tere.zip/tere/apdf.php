<?php
require('fpdf181/fpdf.php');
//include_once("Utils.php");

    $cliente = $_GET['cliente'];
    $nif = $_GET['nif'];
    $dom = $_GET['dom'];
    $pago = $_GET['pago'];
    
    $precio1 = $_GET['precio1'];
    $precio2 = $_GET['precio2'];
    $precio3 = $_GET['precio3'];
    $precio4 = $_GET['precio4'];
    $precio5 = $_GET['precio5'];
    $precio6 = $_GET['precio6'];
    $precio7 = $_GET['precio7'];
    $precio8 = $_GET['precio8'];
    $precio9 = $_GET['precio9'];
    $precio10 = $_GET['precio10'];
    $precio11 = $_GET['precio11'];
    
    $cantidad1 = $_GET['cantidad1'];
    $cantidad2 = $_GET['cantidad2'];
    $cantidad3 = $_GET['cantidad3'];
    $cantidad4 = $_GET['cantidad4'];
    $cantidad5 = $_GET['cantidad5'];
    $cantidad6 = $_GET['cantidad6'];
    $cantidad7 = $_GET['cantidad7'];
    $cantidad8 = $_GET['cantidad8'];
    $cantidad9 = $_GET['cantidad9'];
    $cantidad10 = $_GET['cantidad10'];
    $cantidad11 = $_GET['cantidad11'];




    $pdf=new FPDF();
    $pdf->AddPage();
    $pdf->SetMargins(25,0,0);
    $pdf->SetTitle('FACTURA');
    $pdf->SetFont('Arial','B',16);
    $pdf->Image('logo.jpg' , 10 ,10, 'JPG');
    $pdf->Cell(80,20,'');
    $pdf->MultiCell(40,20,'Factura',0,'C');
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(30,5,'Fecha:' ,'BTL','c');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(130,5,'2','BTR');
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(30,5,'Cliente:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(130,5, $values->cliente ,'BR');
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(30,5,'nif:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(130,5,$values->nif,'BR');
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(30,5,'Domicilio:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(130,5,$values->dom,'BR');
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(30,5,'Pago:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(130,5,$values->pago ,'BR');
    $pdf->SetFont('Arial','B',8);
    $pdf->SetFillColor(224,2,25);
    $pdf-> SetLineWidth(0.4);

    $pdf->Cell(100,5,'Producto',1,0,'C',true);
    $pdf->Cell(20,5,'Precio',1,0,'C',true);
    $pdf->Cell(20,5,'Cantidad',1,0,'C',true);
    $pdf->Cell(20,5,'Importe',1,1,'C',true);
    $pdf->SetFont('Arial','',8);

 
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

     
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);
         
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);


        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

         
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

         
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

         
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

         
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);
         
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

        
        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

        $pdf->Cell(100,5,'kwjbhfjdfjd',1);
        $pdf->Cell(20,5,'50�',1);
        $pdf->Cell(20,5,'50',1);
        $pdf->MultiCell(20,5,'50',1);

    $pdf-> SetLineWidth(0);
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(120,5,'Total bruto:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->Cell(20,5,'50','BL');
    $pdf->MultiCell(20,5,' ','R');
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(120,5,'Precio de Venta:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(40,5,'20' .' �',1);
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(120,5,'Comision Comercial:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(40,5,'50' .' �',1);
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(120,5,'Beneficio:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(40,5,'211' .' �',1);
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(60,25,'Notas:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(100,25,'factura carniceria' ,1);
    $pdf->SetFont('Arial','B',8);
    $pdf->Cell(60,5,'Metodo de pago:','BL');
    $pdf->SetFont('Arial','',8);
    $pdf->MultiCell(100,5,'tarjeta' ,1);

$pdf->Output('Pedido n� 43.pdf','I');
?>
