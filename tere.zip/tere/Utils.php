<?php

class Utils
{
    public static function isValid($value)
    {
        return ($value !== null && $value !== false && $value !== "");
    }

    public static function getInputValue($type, $key, $filter, $options = [], $default = false)
    {
        $value = filter_input($type, $key, $filter, $options);
        if (self::isValid($value) === false) {
            return $default;
        }
        return $value;
    }

    public static function getIn($var, array $keys, $default = null)
    {
        if (empty($keys)) {
            return $var;
        }

        $current = $var;
        foreach ($keys as $key) {
            if (is_object($current) && property_exists($current, $key)) {
                $current = $current->{$key};
            } else if (is_array($current) && array_key_exists($key, $current)) {
                $current = $current[$key];
            } else {
                return $default;
            }
        }
        return $current;
    }

    public static function unsetAndReindex($arr, $index)
    {
        unset($arr[$index]);
        return array_values($arr);
    }
}
