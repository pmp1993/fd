<!doctype html>
 <html>

   <head>
      <meta charset="utf-8"/>   
      <title>Formulario de Factura</title>
   <style type="text/css">
   .ancho {
	width: 98%;
}
   .precio {
	width: 78%;
} 
   </style>
   </head>

   <body>
   <img src="logo.jpg" width="136" height="54"  alt=""/><br>
   <form id="form1" name="form1" method="get" action="apdf.php">
     
       
         <br>
       <label >Nombre del Cliente:</label>
       <input type="text" name="cliente" id="cliente">
       <br>
    
       <label for="textfield2">N.I.F./ C.I.F.:</label>
       <input type="text" name="nif" id="nif">
            <br>

     <label for="textfield3">Domicilio:</label>
       <input name="dom" type="text" id="dom">
              <br>
 
     <label for="textfield4">Pago:</label>
     <input type="text" name="pago" id="pago">
   <table width="644" border="1">
     <tr>
       <th width="144" scope="col">Cantidad</th>
       <th width="259" scope="col">Concepto-Referencia</th>
       <th width="144" scope="col">Precio</th>
       <th width="69" scope="col">Importe</th>
     </tr>
     <tr>
       <td><input type="number" name="cantidad1" id="cantidad1" value="0"></td>
       <td ><input name="concep1" type="text" class="ancho" id="concep1" value=" "  ></td>
       <td><input name="precio1" type="text" class="precio" id="precio1"> €</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad2" id="cantidad2" value="0"></td>
       <td><input name="concep2" type="text" class="ancho" id="concep2" value=" "  ></td>
       <td><input name="precio2" type="text" class="precio" id="precio2">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad3" id="cantidad3" value="0"></td>
       <td><input name="concep3" type="text" class="ancho" id="concep3" value=" "  ></td>
       <td><input name="precio3" type="text" class="precio" id="precio3">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad4" id="cantidad4" value="0"></td>
       <td><input name="concep4" type="text" class="ancho" id="concep4" value=" "  ></td>
       <td><input name="precio4" type="text" class="precio" id="precio4">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad5" id="cantidad5" value="0"></td>
       <td><input name="concep5" type="text" class="ancho" id="concep5" value=" "  ></td>
       <td><input name="precio5" type="text" class="precio" id="precio5">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad6" id="cantidad6" value="0"></td>
       <td><input name="concep6" type="text" class="ancho" id="concep6" value=" "  ></td>
       <td><input name="precio6" type="text" class="precio" id="precio6">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad7" id="cantidad7" value="0"></td>
       <td><input name="concep7" type="text" class="ancho" id="concep7" value=" "  ></td>
       <td><input name="precio7" type="text" class="precio" id="precio7">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad8" id="cantidad8" value="0"></td>
       <td><input name="concep8" type="text" class="ancho" id="concep8" value=" "  ></td>
       <td><input name="precio8" type="text" class="precio" id="precio8">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad9" id="cantidad9" value="0"></td>
       <td><input name="concep9" type="text" class="ancho" id="concep9" value=" "  ></td>
       <td><input name="precio9" type="text" class="precio" id="precio9">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad10" id="cantidad10" value="0"></td>
       <td><input name="concep10" type="text" class="ancho" id="concep10" value=" "  ></td>
       <td><input name="precio10" type="text" class="precio" id="precio10">
€</td>
       <td>&nbsp;</td>
     </tr>
     <tr>
       <td><input type="number" name="cantidad11" id="cantidad11" value="0"></td>
       <td><input name="concep11" type="text" class="ancho" id="concep11" value=" "  ></td>
       <td><input name="precio11" type="text" class="precio" id="precio11">
€</td>
       <td>&nbsp;</td>
     </tr>
   </table>
   <input type="submit" name="crear" value="Crear Factura">
      </form>

   </body>

 </html>